import { Router } from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import { db, shipmentsTable, trackingEventsTable, paymentsTable, usersTable } from "@workspace/db";
import { eq, and, ilike, or, count, desc, SQL } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import { generateTrackingNumber } from "../lib/trackingNumber";
import { createNotification } from "../lib/notifications";

const router = Router();

const UPLOADS_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `delivery-${Date.now()}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

function serializeShipment(s: typeof shipmentsTable.$inferSelect & { customerName?: string | null; driverName?: string | null }) {
  return {
    id: s.id,
    trackingNumber: s.trackingNumber,
    customerId: s.customerId,
    driverId: s.driverId,
    customerName: (s as any).customerName ?? null,
    driverName: (s as any).driverName ?? null,
    serviceType: s.serviceType,
    status: s.status,
    originAddress: s.originAddress,
    originCity: s.originCity,
    originState: s.originState,
    originZip: s.originZip,
    destinationAddress: s.destinationAddress,
    destinationCity: s.destinationCity,
    destinationState: s.destinationState,
    destinationZip: s.destinationZip,
    weightKg: s.weightKg,
    dimensions: s.dimensions,
    description: s.description,
    estimatedDelivery: s.estimatedDelivery,
    deliveryProofUrl: s.deliveryProofUrl,
    totalAmount: s.totalAmount,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
  };
}

// GET /api/shipments
router.get("/shipments", requireAuth, async (req, res) => {
  try {
    const { status, search, page = "1", limit = "20", customerId, driverId } = req.query as Record<string, string>;
    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, parseInt(limit));
    const offset = (pageNum - 1) * limitNum;

    const conditions: SQL[] = [];
    // Role-based filtering
    if (req.user!.role === "customer") conditions.push(eq(shipmentsTable.customerId, req.user!.id));
    if (req.user!.role === "driver") conditions.push(eq(shipmentsTable.driverId, req.user!.id));
    // Admin filters
    if (req.user!.role === "admin" && customerId) conditions.push(eq(shipmentsTable.customerId, parseInt(customerId)));
    if (req.user!.role === "admin" && driverId) conditions.push(eq(shipmentsTable.driverId, parseInt(driverId)));
    if (status) conditions.push(eq(shipmentsTable.status, status as any));
    if (search) conditions.push(
      or(
        ilike(shipmentsTable.trackingNumber, `%${search}%`),
        ilike(shipmentsTable.originCity, `%${search}%`),
        ilike(shipmentsTable.destinationCity, `%${search}%`),
      )!
    );

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const [totalResult, shipments] = await Promise.all([
      db.select({ count: count() }).from(shipmentsTable).where(whereClause),
      db.select().from(shipmentsTable).where(whereClause).orderBy(desc(shipmentsTable.createdAt)).limit(limitNum).offset(offset),
    ]);

    res.json({
      data: shipments.map(serializeShipment),
      total: Number(totalResult[0]?.count ?? 0),
      page: pageNum,
      limit: limitNum,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/shipments
router.post("/shipments", requireRole("customer", "admin"), async (req, res) => {
  try {
    const {
      serviceType, originAddress, originCity, originState, originZip,
      destinationAddress, destinationCity, destinationState, destinationZip,
      weightKg, dimensions, description, senderName, senderPhone, recipientName, recipientPhone,
    } = req.body;

    if (!originAddress || !destinationAddress || !weightKg) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    let trackingNumber: string;
    let attempts = 0;
    do {
      trackingNumber = generateTrackingNumber();
      attempts++;
      if (attempts > 10) break;
      const existing = await db.select({ id: shipmentsTable.id }).from(shipmentsTable).where(eq(shipmentsTable.trackingNumber, trackingNumber)).limit(1);
      if (existing.length === 0) break;
    } while (true);

    const customerId = req.user!.role === "admin" ? (req.body.customerId || req.user!.id) : req.user!.id;

    const [shipment] = await db.insert(shipmentsTable).values({
      trackingNumber,
      customerId,
      serviceType: serviceType || "standard",
      status: "pending",
      originAddress, originCity, originState, originZip,
      destinationAddress, destinationCity, destinationState, destinationZip,
      weightKg: String(weightKg),
      dimensions, description,
      senderName, senderPhone, recipientName, recipientPhone,
    }).returning();

    // Create initial tracking event
    await db.insert(trackingEventsTable).values({
      shipmentId: shipment.id,
      status: "pending",
      description: "Shipment booked and awaiting processing",
      location: originCity,
    });

    // Notify admin
    await createNotification(
      customerId,
      "Shipment Booked",
      `Your shipment ${trackingNumber} has been booked successfully.`,
      "shipment_update",
      shipment.id
    );

    res.status(201).json(serializeShipment(shipment));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/shipments/:id
router.get("/shipments/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [shipment] = await db.select().from(shipmentsTable).where(eq(shipmentsTable.id, id)).limit(1);
    if (!shipment) {
      res.status(404).json({ error: "Shipment not found" });
      return;
    }
    // Access control
    if (req.user!.role === "customer" && shipment.customerId !== req.user!.id) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (req.user!.role === "driver" && shipment.driverId !== req.user!.id) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const [events, payment] = await Promise.all([
      db.select().from(trackingEventsTable).where(eq(trackingEventsTable.shipmentId, id)).orderBy(trackingEventsTable.createdAt),
      db.select().from(paymentsTable).where(eq(paymentsTable.shipmentId, id)).limit(1),
    ]);

    res.json({
      ...serializeShipment(shipment),
      events,
      payment: payment[0] ?? null,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// PATCH /api/shipments/:id
router.patch("/shipments/:id", requireRole("admin", "driver"), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, driverId, estimatedDelivery, totalAmount } = req.body;

    const [existing] = await db.select().from(shipmentsTable).where(eq(shipmentsTable.id, id)).limit(1);
    if (!existing) {
      res.status(404).json({ error: "Shipment not found" });
      return;
    }
    // Driver can only update their assigned shipments
    if (req.user!.role === "driver" && existing.driverId !== req.user!.id) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const updates: Partial<typeof shipmentsTable.$inferInsert> = { updatedAt: new Date() };
    if (status) updates.status = status;
    if (driverId !== undefined) updates.driverId = driverId;
    if (estimatedDelivery) updates.estimatedDelivery = estimatedDelivery;
    if (totalAmount !== undefined) updates.totalAmount = String(totalAmount);

    const [updated] = await db.update(shipmentsTable).set(updates).where(eq(shipmentsTable.id, id)).returning();

    // Notify customer of status change
    if (status && status !== existing.status) {
      await createNotification(
        existing.customerId,
        "Shipment Status Updated",
        `Your shipment ${existing.trackingNumber} status has changed to ${status.replace(/_/g, " ")}.`,
        "shipment_update",
        id
      );
    }

    res.json(serializeShipment(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// DELETE /api/shipments/:id
router.delete("/shipments/:id", requireRole("admin"), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db.delete(shipmentsTable).where(eq(shipmentsTable.id, id)).returning({ id: shipmentsTable.id });
    if (!deleted) {
      res.status(404).json({ error: "Shipment not found" });
      return;
    }
    res.json({ message: "Shipment deleted" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/shipments/:id/assign
router.post("/shipments/:id/assign", requireRole("admin"), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { driverId } = req.body;
    if (!driverId) {
      res.status(400).json({ error: "driverId is required" });
      return;
    }
    const [updated] = await db.update(shipmentsTable).set({ driverId, status: "confirmed", updatedAt: new Date() }).where(eq(shipmentsTable.id, id)).returning();
    if (!updated) {
      res.status(404).json({ error: "Shipment not found" });
      return;
    }
    await createNotification(
      updated.customerId,
      "Driver Assigned",
      `A driver has been assigned to your shipment ${updated.trackingNumber}.`,
      "driver_assignment",
      id
    );
    res.json(serializeShipment(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/shipments/:id/events
router.get("/shipments/:id/events", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const events = await db.select().from(trackingEventsTable).where(eq(trackingEventsTable.shipmentId, id)).orderBy(trackingEventsTable.createdAt);
    res.json(events);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/shipments/:id/events
router.post("/shipments/:id/events", requireRole("admin", "driver"), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, location, description } = req.body;
    if (!status || !description) {
      res.status(400).json({ error: "status and description are required" });
      return;
    }
    const [event] = await db.insert(trackingEventsTable).values({ shipmentId: id, status, location, description }).returning();

    // Also update shipment status
    const [shipment] = await db.update(shipmentsTable).set({ status, updatedAt: new Date() }).where(eq(shipmentsTable.id, id)).returning();
    if (shipment) {
      await createNotification(shipment.customerId, "Shipment Update", description, "shipment_update", id);
    }

    res.status(201).json(event);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/shipments/:id/proof
router.post("/shipments/:id/proof", requireRole("driver", "admin"), upload.single("file"), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (!req.file) {
      res.status(400).json({ error: "No file uploaded" });
      return;
    }
    const proofUrl = `/api/uploads/${req.file.filename}`;
    const [updated] = await db.update(shipmentsTable).set({ deliveryProofUrl: proofUrl, status: "delivered", updatedAt: new Date() }).where(eq(shipmentsTable.id, id)).returning();
    if (!updated) {
      res.status(404).json({ error: "Shipment not found" });
      return;
    }
    await db.insert(trackingEventsTable).values({
      shipmentId: id,
      status: "delivered",
      description: "Package delivered. Proof of delivery uploaded.",
      location: req.body.notes || undefined,
    });
    await createNotification(updated.customerId, "Shipment Delivered", `Your shipment ${updated.trackingNumber} has been delivered.`, "shipment_update", id);
    res.json(serializeShipment(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
