import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useCreateShipment, useCreatePayment, useListPricing, ShipmentInputServiceType, PaymentInputCurrency } from '@workspace/api-client-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { Package, MapPin, Truck, CheckCircle2, ChevronRight, Loader2, CreditCard } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const step1Schema = z.object({
  serviceType: z.nativeEnum(ShipmentInputServiceType),
  weightKg: z.coerce.number().min(0.1, "Weight must be greater than 0"),
  dimensions: z.string().optional(),
  description: z.string().optional(),
});

const step2Schema = z.object({
  originAddress: z.string().min(5, "Address is required"),
  originCity: z.string().min(2, "City is required"),
  originState: z.string().min(2, "State is required"),
  originZip: z.string().min(5, "ZIP code is required"),
  destinationAddress: z.string().min(5, "Address is required"),
  destinationCity: z.string().min(2, "City is required"),
  destinationState: z.string().min(2, "State is required"),
  destinationZip: z.string().min(5, "ZIP code is required"),
});

const step4Schema = z.object({
  currency: z.nativeEnum(PaymentInputCurrency),
});

// Combined schema for final submission
const bookingSchema = step1Schema.merge(step2Schema).merge(step4Schema);
type BookingValues = z.infer<typeof bookingSchema>;

export default function BookShipment() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [finalTracking, setFinalTracking] = useState('');
  const { data: pricing } = useListPricing();
  
  const form = useForm<BookingValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      serviceType: ShipmentInputServiceType.standard,
      weightKg: 1,
      dimensions: '',
      description: '',
      originAddress: '', originCity: '', originState: '', originZip: '',
      destinationAddress: '', destinationCity: '', destinationState: '', destinationZip: '',
      currency: PaymentInputCurrency.BTC,
    },
    mode: "onChange"
  });

  const createShipment = useCreateShipment();
  const createPayment = useCreatePayment();

  const handleNext = async () => {
    let isValid = false;
    if (step === 1) {
      isValid = await form.trigger(['serviceType', 'weightKg', 'dimensions', 'description']);
    } else if (step === 2) {
      isValid = await form.trigger([
        'originAddress', 'originCity', 'originState', 'originZip',
        'destinationAddress', 'destinationCity', 'destinationState', 'destinationZip'
      ]);
    } else if (step === 3) {
      isValid = true;
    }
    
    if (isValid) {
      setStep(s => s + 1);
    }
  };

  const onSubmit = async (data: BookingValues) => {
    try {
      // Calculate estimated price
      const selectedService = pricing?.find(p => p.serviceType === data.serviceType);
      const estimatedPrice = selectedService ? (Number(selectedService.basePriceUsd) + (data.weightKg * Number(selectedService.pricePerKg))) : 0;

      // 1. Create Shipment
      const shipment = await createShipment.mutateAsync({ data });
      
      // 2. Create Payment
      await createPayment.mutateAsync({ 
        data: {
          shipmentId: shipment.id,
          amount: parseFloat(estimatedPrice.toFixed(2)),
          currency: data.currency
        } 
      });

      toast.success("Shipment booked successfully!");
      setFinalTracking(shipment.trackingNumber);
      setStep(5); // Success step
    } catch (err: any) {
      toast.error(err?.data?.error || "Failed to book shipment.");
    }
  };

  const steps = [
    { id: 1, title: 'Package Details', icon: Package },
    { id: 2, title: 'Route Details', icon: MapPin },
    { id: 3, title: 'Review', icon: CheckCircle2 },
    { id: 4, title: 'Payment', icon: CreditCard }
  ];

  // Calculate estimated price
  const watchValues = form.watch();
  const selectedService = pricing?.find(p => p.serviceType === watchValues.serviceType);
  const estimatedPrice = selectedService ? (Number(selectedService.basePriceUsd) + (watchValues.weightKg * Number(selectedService.pricePerKg))).toFixed(2) : '0.00';

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-secondary mb-2">Book a Shipment</h1>
        <p className="text-gray-500">Fill out the details below to schedule your delivery.</p>
      </div>

      {/* Progress Steps */}
      {step < 5 && (
        <div className="flex items-center justify-between mb-12 relative">
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10 -translate-y-1/2 rounded-full"></div>
          <div 
            className="absolute top-1/2 left-0 h-1 bg-primary -z-10 -translate-y-1/2 rounded-full transition-all duration-500 ease-in-out"
            style={{ width: `${((step - 1) / 3) * 100}%` }}
          ></div>
          
          {steps.map((s) => (
            <div key={s.id} className="flex flex-col items-center gap-2 bg-gray-50 px-2">
              <div className={`h-12 w-12 rounded-full flex items-center justify-center transition-colors duration-300 border-4 border-gray-50 shadow-sm
                ${step >= s.id ? 'bg-primary text-white' : 'bg-white text-gray-400 border-gray-200'}
              `}>
                <s.icon className="h-5 w-5" />
              </div>
              <span className={`text-sm font-medium ${step >= s.id ? 'text-secondary' : 'text-gray-400'}`}>{s.title}</span>
            </div>
          ))}
        </div>
      )}

      <Card className="shadow-lg border-0 bg-white">
        <CardContent className="p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <AnimatePresence mode="wait">
                
                {/* STEP 1 */}
                {step === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-6"
                  >
                    <h2 className="text-xl font-bold text-secondary border-b pb-4">What are you shipping?</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="serviceType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Service Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="h-12">
                                  <SelectValue placeholder="Select service" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {pricing?.map(p => (
                                  <SelectItem key={p.id} value={p.serviceType}>
                                    {p.serviceType.charAt(0).toUpperCase() + p.serviceType.slice(1)} - {p.estimatedDays}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="weightKg"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Weight (kg)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" className="h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="dimensions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Dimensions (Optional, L x W x H)</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 20x20x20 cm" className="h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Package Contents (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="Electronics, documents, etc." className="h-12" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </motion.div>
                )}

                {/* STEP 2 */}
                {step === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-8"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Origin */}
                      <div className="space-y-6">
                        <h2 className="text-xl font-bold text-secondary border-b pb-4 flex items-center gap-2">
                          <MapPin className="h-5 w-5 text-gray-400" /> Origin
                        </h2>
                        
                        <FormField
                          control={form.control}
                          name="originAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Street Address</FormLabel>
                              <FormControl>
                                <Input className="h-12" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="originCity"
                            render={({ field }) => (
                              <FormItem className="col-span-2 sm:col-span-1">
                                <FormLabel>City</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="originState"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="originZip"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ZIP Code</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Destination */}
                      <div className="space-y-6">
                        <h2 className="text-xl font-bold text-secondary border-b pb-4 flex items-center gap-2">
                          <MapPin className="h-5 w-5 text-primary" /> Destination
                        </h2>
                        
                        <FormField
                          control={form.control}
                          name="destinationAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Street Address</FormLabel>
                              <FormControl>
                                <Input className="h-12" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="destinationCity"
                            render={({ field }) => (
                              <FormItem className="col-span-2 sm:col-span-1">
                                <FormLabel>City</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="destinationState"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="destinationZip"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ZIP Code</FormLabel>
                                <FormControl><Input className="h-12" {...field} /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* STEP 3 */}
                {step === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-8"
                  >
                    <h2 className="text-2xl font-bold text-secondary text-center mb-8">Review Your Shipment</h2>
                    
                    <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <h4 className="font-semibold text-gray-500 uppercase tracking-wider text-xs mb-4">Route Info</h4>
                        <div className="space-y-4">
                          <div className="flex gap-3">
                            <MapPin className="h-5 w-5 text-gray-400 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium text-secondary">Origin</p>
                              <p className="text-gray-600 text-sm mt-1">{watchValues.originAddress}<br/>{watchValues.originCity}, {watchValues.originState} {watchValues.originZip}</p>
                            </div>
                          </div>
                          <div className="h-8 border-l-2 border-dashed border-gray-300 ml-2.5"></div>
                          <div className="flex gap-3">
                            <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium text-secondary">Destination</p>
                              <p className="text-gray-600 text-sm mt-1">{watchValues.destinationAddress}<br/>{watchValues.destinationCity}, {watchValues.destinationState} {watchValues.destinationZip}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-gray-500 uppercase tracking-wider text-xs mb-4">Package Info</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex justify-between"><span className="text-gray-600">Service:</span> <span className="font-medium text-secondary capitalize">{watchValues.serviceType}</span></li>
                            <li className="flex justify-between"><span className="text-gray-600">Weight:</span> <span className="font-medium text-secondary">{watchValues.weightKg} kg</span></li>
                            {watchValues.dimensions && <li className="flex justify-between"><span className="text-gray-600">Dimensions:</span> <span className="font-medium text-secondary">{watchValues.dimensions}</span></li>}
                          </ul>
                        </div>

                        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                          <h4 className="font-semibold text-gray-500 uppercase tracking-wider text-xs mb-2">Estimated Cost</h4>
                          <div className="text-3xl font-extrabold text-secondary">${estimatedPrice}</div>
                          <p className="text-xs text-gray-500 mt-1">Select payment method in the next step.</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* STEP 4 */}
                {step === 4 && (
                  <motion.div
                    key="step4"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-8"
                  >
                    <h2 className="text-xl font-bold text-secondary border-b pb-4">Payment Method</h2>
                    
                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Cryptocurrency</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="h-12 text-lg">
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {Object.values(PaymentInputCurrency).map((currency) => (
                                <SelectItem key={currency} value={currency}>
                                  {currency.replace('_', ' ')}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <p className="text-sm text-gray-500 mt-2">
                            Total to pay: <span className="font-bold text-secondary">${estimatedPrice}</span> (converted at payment time)
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg flex items-start gap-3">
                      <CreditCard className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                      <p className="text-sm text-blue-800">
                        After confirming, you will be redirected to the payments page where you'll find the deposit address to complete your transaction.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* STEP 5: SUCCESS */}
                {step === 5 && (
                  <motion.div
                    key="step5"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-12 text-center space-y-6"
                  >
                    <div className="h-20 w-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle2 className="h-10 w-10" />
                    </div>
                    <h2 className="text-3xl font-bold text-secondary">Shipment Booked!</h2>
                    <p className="text-gray-600 max-w-md mx-auto">
                      Your shipment is currently pending. Please complete your payment to proceed with shipping.
                    </p>
                    <div className="bg-gray-50 p-6 rounded-xl inline-block mt-4 mb-8 border border-gray-200">
                      <p className="text-sm text-gray-500 uppercase tracking-wider font-semibold mb-2">Tracking Number</p>
                      <p className="text-3xl font-mono font-bold text-secondary tracking-tight">{finalTracking}</p>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
                      <Button onClick={() => setLocation('/dashboard/payments')} className="h-12 px-8 text-lg" size="lg">
                        Go to Payments
                      </Button>
                      <Button onClick={() => setLocation(`/dashboard/tracking/${finalTracking}`)} variant="outline" className="h-12 px-8 text-lg" size="lg">
                        Track Shipment
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Navigation Buttons */}
              {step < 5 && (
                <div className="mt-12 flex justify-between pt-6 border-t border-gray-100">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setStep(s => Math.max(1, s - 1))}
                    disabled={step === 1 || createShipment.isPending || createPayment.isPending}
                    className="h-12 px-6"
                  >
                    Back
                  </Button>
                  
                  {step < 4 ? (
                    <Button 
                      type="button" 
                      onClick={handleNext}
                      className="h-12 px-8 bg-secondary hover:bg-secondary/90 text-white"
                    >
                      Next Step <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button 
                      type="submit" 
                      disabled={createShipment.isPending || createPayment.isPending}
                      className="h-12 px-10 bg-primary hover:bg-primary/90 text-lg"
                    >
                      {(createShipment.isPending || createPayment.isPending) && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
                      Confirm & Book
                    </Button>
                  )}
                </div>
              )}
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
